package forSort;

public class theKthQuickSort {
    public static void main(String[] args) {
        int[] nums = new int[]{99,99};
        int k = 1;
        findKthLargest(nums,k);

    }
    public static int findKthLargest(int[] nums, int k) {
        k --;
        int left = 0, right = nums.length - 1;
        while(left < right) {
            int temp = quickSort(nums,left,right);//1
            System.out.println("===" + temp);
            if(temp < k) {
                left = temp + 1;
            }else if(temp > k) {
                right = temp - 1;
            }else {
                return nums[temp];
            }
        }
        return nums[k];
    }

    public static int quickSort(int[] nums,int left,int right) {
        int tempNum = nums[left];
        int tempIndex = left;
        while(left < right) {
            while(right > left && nums[right] < tempNum) {
                right --;
            }
            while(left < right && nums[left] >= tempNum) {
                left ++;
            }
            if(left > right) break;
            swap(nums,left,right);
        }
        nums[tempIndex] = nums[left];
        nums[left] = tempNum;
        return left;
    }

    public static void swap(int[] nums,int left,int right) {
        int t1 = nums[left];
        nums[left] = nums[right];
        nums[right] = t1;
    }
}
