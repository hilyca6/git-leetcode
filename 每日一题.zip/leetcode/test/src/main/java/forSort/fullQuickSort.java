package forSort;

import java.util.Scanner;

public class fullQuickSort {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] nums = new int[n];
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        quickSort(nums, 0, n - 1);
        for(int num : nums) {
            System.out.print(num);
        }
    }

    public static void quickSort(int[] nums, int left, int right) {
        if (left >= right) return;
        int l = left,r = right;
        int tempNum = nums[left];
        int Index = left;
        while (l < r) {
            while (l < r && nums[r] > tempNum) {
                r--;
            }
            while (l < r && nums[l] <= tempNum) {
                l++;
            }
            if (l >= r) break;
            swap(nums, l, r);
        }
        nums[Index] = nums[l];
        nums[l] = tempNum;
        quickSort(nums,left,l - 1);
        quickSort(nums,l + 1,right);
    }

    private static void swap(int[] nums, int left, int right) {
        int temp = nums[left];
        nums[left] = nums[right];
        nums[right] = temp;
    }
}
