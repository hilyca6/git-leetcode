public interface Iwork {
    void meeting();
    void evaluate();
}
