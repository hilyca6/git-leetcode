public final class SingleTon {
    private static volatile SingleTon Instance = null;
    private static SingleTon getInstance() {
        if(Instance == null) {
            synchronized (SingleTon.class) {
                if(Instance == null) {
                    Instance = new SingleTon();
                }
            }
        }
        return Instance;
    }
    public static void main(String[] args) {
        System.out.println(getInstance());
    }
}
