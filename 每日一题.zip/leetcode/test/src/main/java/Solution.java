import java.util.Arrays;

public class Solution {
    public static void main(String[] args) {
        int[] nums = new int[]{4,2,5,1};
        Solution solution = new Solution();
        solution.findKthLargest(nums,2);
    }
    public int findKthLargest(int[] nums, int k) {
        int left = 0, right = nums.length - 1;
        k = k -1;
        while(true) {
            int temp = findKthNum(nums,left,right);
            // System.out.println("======" + String.valueOf(nums));
            if(temp == k) {
                return nums[k];
            }else if(temp < k) {
                left = temp + 1;
            }else {
                right = temp - 1;
            }
        }
    }

    private int findKthNum(int[] nums, int left, int right) {
        int temp = nums[left];
        int tempIndex = left;
        while(left < right) {

            while(nums[left] >= temp && left < right) {
                left ++;
            }
            while(nums[right] <= temp && right > left) {
                right --;
            }
            if(left >= right) break;
            swap(nums,left,right);
        }
        swap(nums,tempIndex,left);
        System.out.println(Arrays.toString(nums));
        return left;
    }
    private void swap(int[] nums,int left, int right) {
        int temp = nums[left];
        nums[left] = nums[right];
        nums[right] = temp;
    }
}
