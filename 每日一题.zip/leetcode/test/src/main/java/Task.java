import java.util.concurrent.*;

public class Task implements Callable<String> {
    public String call() throws Exception {
        return "hello world";
    }

    public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException {
        ExecutorService executorService = Executors.newCachedThreadPool();
        Task task = new Task();
        Future<String> submit = executorService.submit(task);
        System.out.println(submit.get(1,TimeUnit.HOURS));
        threadDemo();
    }

    private static void threadDemo() throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newCachedThreadPool();
        FutureTask<String> task  = new FutureTask<String>(new Task());
        executorService.submit(task);
        System.out.println(task.get());
    }
}
