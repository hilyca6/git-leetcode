public class Practice {
    public static void main(String[] args) {
        String str1 = "abc";
        String str2 = "ing";
        String str3 = str1 + str2;
        String str4 = "abc" + "ing";
        String str5 = "abcing";
        System.out.println("str1=="+str1.hashCode());
        System.out.println("str2=="+str2.hashCode());
        System.out.println(str3 == str5);
        System.out.println(str4 == str5);
        System.out.println("str5=="+str5.hashCode());
    }
}

class HH{
    int b;
}