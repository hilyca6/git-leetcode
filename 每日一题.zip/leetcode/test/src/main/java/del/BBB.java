package del;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BBB extends AAA {
    @Override
    public void printName() {
        System.out.println("lll");
    }

    public static void main(String[] args) {
        BBB bbb = new BBB();
        bbb.setAge(1);
        bbb.setName("aa");
        bbb.printName();
        System.out.println(42 == 42.0);
        Map<String,String> map = new HashMap<>(16);
        map.put(null,null);
        map.put(null,"1");
        int[][] a = new int[11][11];
    }
}
