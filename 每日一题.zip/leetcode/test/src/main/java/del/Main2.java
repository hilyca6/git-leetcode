package del;

import java.sql.*;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Logger;

public class Main2 {
    private  static  int res = 0;
    private  static  int total = 0;

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        String s = scanner.nextLine();
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int x = scanner.nextInt();

        if(x < a) {
            System.out.println(String.format("%.4f",0));
        }
        method1(n,a,b,x,a);
        double temp = (double) res / total;
        System.out.println(String.format("%.4f",temp));
    }
    private static void method1(int n,int a,int b,int x,int start){
        if(n == 0) {
            total +=1;
            return;
        }
        for (int i = start; i <= b; i++) {
            x -= i;
            n -= 1;
            if(x == 0 && n == 0) {
                res ++;
                x += i;
                n += 1;
                total += 1;
                continue;
            }
            method1(n,a,b,x,i + 1);
            x += i;
            n += 1;
        }
    }
}
