package del;

import java.util.*;

public class Main4 {
    public static void main(String[] args) {
//        int b1,b2,b3;
//        for (int i = 101; i < 1000; i++) {
//            b1 = i / 100;
//            b2 = i % 100 / 10;
//            b3 = i % 10;
//            if(i == b1 * b1 * b1 + b2 * b2 * b2 + b3 * b3 * b3) {
//                System.out.println(i);
//            }
//        }

    }
}
