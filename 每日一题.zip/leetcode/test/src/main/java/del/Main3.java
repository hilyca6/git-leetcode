package del;

import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.*;

public class Main3 {
    public static volatile int count = 10;
    public static void main(String[] args) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                5,
                10,
                2,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(3),
                Executors.defaultThreadFactory(),
                new ThreadPoolExecutor.DiscardPolicy());


        try {
            threadPoolExecutor.execute(() -> {
                for (int i = 0; i < 20; i++) {
                    count ++;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            threadPoolExecutor.shutdown();
        }

    }
}