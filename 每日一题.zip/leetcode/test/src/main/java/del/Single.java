package del;

public final class Single {
    private Single(){};
    private static volatile Single single = null;
    public Single getInstance() {
        if(single == null) {
            synchronized (Single.class) {
                if(single == null) {
                    single = new Single();
                }
            }
        }
        return single;
    }
}
