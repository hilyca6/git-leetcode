package del;

import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        int[][] ints = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                ints[i][j] = i + j + 5;
            }
        }
        int[] anInt = ints[2];
        System.out.println(anInt[2]);
    }


}
