package del;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
public final class streamTest {
    public static void main(String[] args) {
        streamTest st = new streamTest();
        st.test2();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("jvavaa");
        System.out.println(stringBuilder.deleteCharAt(stringBuilder.length() - 1).toString());


    }

//    private void test1() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("请输入：");
//        int a = 0, b = 0,c = 0;
//        while (scanner.hasNextInt()) {
//            a = scanner.nextInt();
//            b = scanner.nextInt();
//            c = scanner.nextInt();
//            if(c == 111) break;
//        }
//        System.out.println("输出结果是a：" + a);
//        System.out.println("输出结果是b：" + b);
//        System.out.println("输出结果是：" + a * b);
//    }

    private void test2() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入：");
        String a = null, b = null, temp = null;
            a = scanner.nextLine();
            b = scanner.nextLine();

        System.out.println("输出结果是a：" + a);
        System.out.println("输出结果是b：" + b);
    }
//    private void test3() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("请输入：");
//        int a = 0, b = 0,c = 0;
//            a = scanner.nextInt();
//            b = scanner.nextInt();
//
//        System.out.println("输出结果是a：" + a);
//        System.out.println("输出结果是b：" + b);
//        System.out.println("输出结果是：" + a * b);
//    }
}

