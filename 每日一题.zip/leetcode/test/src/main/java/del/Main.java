package del;

import java.math.BigDecimal;
import java.util.*;

public class Main {
    private static int countRes = 0;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int q = scanner.nextInt();
        boolean[][] temp = new boolean[n + 1][n + 1];

        for (int i = 1; i <= n; i++) {
            int count = scanner.nextInt();
            if(count != 0) temp[i][0] = true;
            while (count > 0) {
                int tempIndex = scanner.nextInt();
                temp[i][tempIndex] = true;
                count --;
            }
        }

        while (q > 0) {
            int isStart = scanner.nextInt();
            int index = scanner.nextInt();
//            int count1 = 0;
            boolean[] isUsed = new boolean[n + 1];
            boolean[] shutdownUsed = new boolean[n + 1];//%%%%%%%%%%%%%%%%%%%%
            //为1,开启
            if(isStart == 1 && temp[index][0]) {
                for (int i = 1; i <= n; i++) {
                    if(temp[index][i] == true) {
                        countRes ++;
                        isUsed[i] = true;
                        dfs(temp,i,isUsed);
                    }
                }
                System.out.println(countRes);
//                countRes = 0;//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            }else if(isStart == 1 && !temp[index][0]) {
                System.out.println(1);
            }

            //0,关闭
            if(isStart == 0) {
                if(! temp[index][0]) {
                    System.out.println(countRes);
                }
                if(temp[index][0]){
                    for (int i = 1; i <= n; i++) {
                        if(temp[index][i]) {
                            countRes --;
                            shutdownUsed[i] = true;
                            shutDfs(temp,i,shutdownUsed);
                        }
                    }
                    System.out.println(countRes);
                }
            }
        }

    }

    private static void dfs (boolean[][] temp,int start,boolean[] isUsed) {
        if(start == temp.length || !temp[start][0]) {
            return;
        }

        for (int i = 1; i < temp.length; i++) {
            if(temp[start][0]) {
                if(isUsed[i]) {
                    continue;
                }else {
                    isUsed[i] = true;
                    countRes ++;
                    dfs(temp,i,isUsed);
                }
            }
        }
    }

    private static void shutDfs(boolean[][] temp,int start,boolean[] shutdownUsed) {
        if(!temp[start][0] || start == temp.length) {
            return;
        }

        for (int i = 1; i < temp.length; i++) {
            if(shutdownUsed[i]) {
                continue;
            }else {
                shutdownUsed[i] = true;
                countRes --;
                dfs(temp,i,shutdownUsed);
            }
        }
    }
}
