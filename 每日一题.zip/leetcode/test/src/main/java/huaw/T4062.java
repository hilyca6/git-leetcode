package huaw;

import java.util.HashSet;
import java.util.Scanner;

public class T4062 {//拓扑搜索dfs
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int promNum = Integer.parseInt(scanner.nextLine());
        int tarGram = Integer.parseInt(scanner.nextLine());
        boolean[][] booleans = new boolean[promNum][promNum];
        for (int i = 0; i < promNum; i++) {
            String[] split = scanner.nextLine().split(",");
            int RelNum = Integer.parseInt(split[0]);
            if (RelNum == 0) continue;
            for (int j = 1; j < RelNum; j++) {
                int tempNum = Integer.parseInt(split[j]);
                booleans[i][tempNum] = true; 
            }
        }

        HashSet<Integer> set = new HashSet<>();
        
        for (int i = 0; i < promNum; i++) {
            for (int j = 0; j < promNum; j++) {
                if (! booleans[i][j]) {
                    continue;
                }else {
                    dpSearch(booleans,i,j);
                }
            }
        }
    }
    
    private static void dpSearch(boolean[][] booleans,int row,int col) {
        if (row >= booleans.length || col >= booleans.length || ! booleans[row][col]) {
            return;
        }
        for (int i = 0; i < booleans.length; i++) {
            
        }

    }
}
