package huaw;

import java.util.Scanner;

public class xinyuangongnew {
    private static int res = 0;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int score = scanner.nextInt();
        int[] perScore = new int[25];
        for (int i = 0; i < 25; i++) {
            if(i < 10) {
                perScore[i] = 2;
            }else if (i >= 20) {
                perScore[i] = 8;
            }else {
                perScore[i] = 4;
            }
        }
        searchNum(perScore,0,0,0,score);
        System.out.println(res);
    }

    private static void searchNum(int[] perScore,int i,int total,int errtotal,int score) {
        if (total > score || i > 25 || errtotal >= 3) {
            return;
        }
        if (total == score) {
            res ++;
            return;
        }

        for (int j = i; j < 25; j++) {
            total = total + perScore[j];
            searchNum(perScore,j + 1,total,errtotal,score);
            total = total - perScore[j];
            errtotal ++;
        }
    }
}
