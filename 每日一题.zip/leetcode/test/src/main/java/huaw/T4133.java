package huaw;

import java.util.Scanner;

public class T4133 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int total = scanner.nextInt();
        int[] total_count = new int[total];
        for (int i = 0; i < total; i++) {
            total_count[i] = scanner.nextInt();
        }
        System.out.println(total_count.length);
    }
}
