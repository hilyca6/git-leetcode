package huaw;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;

public class T4131_cpuyingjian {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        int M = scanner.nextInt();
        int M = Integer.parseInt(scanner.nextLine());
        int[][] nums = new int[M][5];
        for (int i = 0; i < M; i++) {
            String str = scanner.nextLine();
            String[] split = str.split(",");
            for (int j = 0; j < 5; j++) {
                nums[i][j] = Integer.parseInt(split[j]);
            }
        }

        int N = scanner.nextInt();
        int strategy = scanner.nextInt();
        int cpuCount = scanner.nextInt();
        int memSize = scanner.nextInt();
        int cupArch = scanner.nextInt();
        int supportNp = scanner.nextInt();

        PriorityQueue<int[]> queue = null;
        if (strategy == 1) { //cpu
            queue = new PriorityQueue<>(
                    (o1,o2)->{
                        if (o1[1] != o2[1]) {
                            return o1[1] - o2[1];
                        }else {
                            if (o1[2] != o2[2]){
                                return o1[2] - o2[2];
                            }else {
                                return o1[0] - o2[0];
                            }
                        }
            });
        }

        if(strategy == 2) {
            queue = new PriorityQueue<>(
                    (o1,o2)->{
                        if (o1[2] != o2[2]) {
                            return o1[2] - o2[2];
                        }else {
                            if (o1[1] != o2[1]){
                                return o1[1] - o2[1];
                            }else {
                                return o1[0] - o2[0];
                            }
                        }
                    });
        }

        for (int i = 0; i < M; i++) {
            if (nums[i][1] >= cpuCount && nums[i][2] >= memSize && (nums[i][3] == cupArch || cupArch == 9) &&
                    (nums[i][4] == supportNp || supportNp == 2)) {
                queue.add(nums[i]);
            }
        }

        int rescount = Math.min(N,queue.size());
        int[] res = new int[rescount];
        for (int i = 0; i < rescount; i++) {
            int[] poll = queue.poll();
            res[i] =poll[0];
        }
        Arrays.sort(res);
        System.out.print(rescount);
        for (int i = 0; i < rescount; i++) {
            System.out.print(" " + res[i]);
        }
    }
}
