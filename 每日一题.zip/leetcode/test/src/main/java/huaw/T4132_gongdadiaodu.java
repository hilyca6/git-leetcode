package huaw;

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Scanner;

public class T4132_gongdadiaodu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = Integer.parseInt(scanner.nextLine());
        int[][] slaI = new int[N][2];
        for (int i = 0; i < N; i++) {
            String[] split = scanner.nextLine().split(" ");
            slaI[i][0] = Integer.parseInt(split[0]);
            slaI[i][1] = Integer.parseInt(split[1]);
        }

        Arrays.sort(slaI,(o1,o2) -> {
            if (o1[0] != o2[0]) {
                return o1[0] - o2[0];
            }else {
                return o2[1] - o1[1];
            }
        });
        PriorityQueue<int[]> queue = new PriorityQueue<>((o1,o2) -> {
            return o1[0] - o2[0];
        });
        if(N < 1) {
            System.out.println(0);
            return;
        }
        queue.add(slaI[0]);
        for (int i = 0; i < N; i++) {
            if(slaI[i][0] > queue.size()) {
                queue.add(slaI[i]);
                continue;
            }
            if(queue.size() == slaI[i][0]) {
                int[] poll = queue.poll();
                if (poll[1] < slaI[i][1]) {
                    queue.add(slaI[i]);
                }else {
                    queue.add(poll);
                }
            }
        }
        int res = 0;
        int count = queue.size();
        for (int i = 0; i < count; i++) {
            res += queue.poll()[1];
        }
        System.out.println(res);

    }
}
