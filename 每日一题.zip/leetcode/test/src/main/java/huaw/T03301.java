package huaw;

import java.util.Scanner;

public class T03301 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int M = Integer.parseInt(scanner.nextLine());
        int N = Integer.parseInt(scanner.nextLine());
        String work = scanner.nextLine();

        int countA = 0;
        int posA=0;
        int posB=0;
        String[] split = work.split(" ");
        for (int i = 0; i < N; i++) {
            if (split[i].equals("B")) {
                if (countA ==1) {
                    posB = posA +1;
                }else  {
                    posB ++;
                }
            }else {
                countA ++;
                if(countA == 1) {
                    posA = posB + 1;
                }
                if (countA % 4 == 0) {
                    countA = 0;
                }
            }
        }

        if(split[split.length - 1].equals('B')){
            System.out.print(posB + "B");
            System.out.print(" 1");
        }else {
            System.out.print(posA + "A");
            if (countA == 0) {
                System.out.print(" 4");
            }else {
                System.out.print(" " + countA);
            }
        }

    }
}
