package huaw;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class creatBtree {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        String sLine = line.substring(1,line.length());
        String[] nodesNum = sLine.split(",");

        if(nodesNum.length == 0 || nodesNum[0].equals(null)){
            System.out.println("-1");
            return;
        }
        Queue<String> queue = new LinkedList<>();
        queue.add(nodesNum[0]);
        TreeNode treeNode = helpCreat(nodesNum, 0,queue);

    }

    private static TreeNode helpCreat(String[] nodesNum,int start,Queue<String> queue) {
        if (start < nodesNum.length) {
            if(! nodesNum[start].equals(null)){
                int temp = Integer.parseInt(nodesNum[start]);
                TreeNode node = new TreeNode(temp);

            }

        }
        return null;

    }


}

class TreeNode {
    int val;
    TreeNode left;
    TreeNode right;

    public TreeNode() {
    }

    public TreeNode(int val) {
        this.val = val;
    }

    public TreeNode(int val, TreeNode left, TreeNode right) {
        this.val = val;
        this.left = left;
        this.right = right;
    }
}