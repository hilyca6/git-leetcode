package huaw;

import java.util.Scanner;

public class huadongchuangkou {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = Integer.parseInt(scanner.nextLine());
        String[] num = scanner.nextLine().split(" ");
        int M = Integer.parseInt(scanner.nextLine());

        int res = 0;
        int maxVal = Integer.MIN_VALUE;
        if(M == 0) {
            System.out.println(0);
            return;
        }
        for (int i = 0; i < M; i++) {
            res += Integer.parseInt(num[i]);
        }
        maxVal = res;
        int left = 0,right = M - 1;
        while (right < N) {
            right ++;
            if (right >= N)break;
            res += Integer.parseInt(num[right]);
            res -= Integer.parseInt(num[left]);
            left ++;
            maxVal = Math.max(maxVal,res);
        }
        System.out.println(maxVal);
    }
}
