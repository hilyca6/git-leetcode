package huaw;

import java.util.Scanner;

public class houzichitao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] s = scanner.nextLine().split(" ");
        int[] num = new int[s.length - 1];
        for (int i = 0; i < s.length - 1; i++) {
            num[i] = Integer.parseInt(s[i]);
        }
        int totalT = Integer.parseInt(s[s.length - 1]);


    }
}
