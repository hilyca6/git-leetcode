package huaw;

import java.util.Scanner;

public class T03302 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] s = scanner.nextLine().split(" ");
        int[][] map = new int[Integer.parseInt(s[0])][Integer.parseInt(s[1])];
        String[] s1 = scanner.nextLine().split(" ");
        String[] s2 = scanner.nextLine().split(" ");
        int[] startPoint = {Integer.parseInt(s1[0]), Integer.parseInt(s1[1])};
        int[] endPoint = {Integer.parseInt(s2[0]), Integer.parseInt(s2[1])};
        int poolNum = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i < poolNum; i++) {
            String[] temp = scanner.nextLine().split(" ");
            int x = Integer.parseInt(temp[0]);
            int y = Integer.parseInt(temp[1]);
            map[x][y] = 1;
        }

        if (map[startPoint[0]][startPoint[1]] == 1 || map[endPoint[0]][endPoint[1]] == 1) {
            System.out.println(-1);
            return;
        }

        helpFindMin(map, endPoint, 0, startPoint[0], startPoint[1]);

        System.out.print(count);
        System.out.print(" " + minLen);
    }

    private static int count = 0;
    private static int minLen = Integer.MAX_VALUE;
    private static int[][] direction = new int[][]{{0, 1}, {1, 0}, {-1, 0}, {0, -1}};

    private static void helpFindMin(int[][] map, int[] endPoint, int pathLen, int X, int Y) {
        if (X < 0 || X > map[0].length || Y < 0 || Y > map.length) {
            return;
        }

        if (X == endPoint[0] && Y == endPoint[1]) {
            if (pathLen < minLen) {
                count = 0;
                count++;
                minLen = pathLen;
                return;
            } else if (pathLen == minLen) {
                count++;
                return;
            } else {
                return;
            }
        }

        helpFindMin(map, endPoint, pathLen + 1, X + 1, Y);
        helpFindMin(map, endPoint, pathLen + 1, X, Y + 1);
        helpFindMin(map, endPoint, pathLen + 1, X - 1, Y);
        helpFindMin(map, endPoint, pathLen + 1, X, Y - 1);
    }
}


