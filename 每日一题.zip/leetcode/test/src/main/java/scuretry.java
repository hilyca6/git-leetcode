public class scuretry implements Iwork {
    private leader leader;
    public scuretry(leader leader) {
        this.leader = leader;
    }
    public void meeting() {
        System.out.println("mishukaihui");
        leader.meeting();
    }

    public void evaluate() {
        leader.evaluate();
    }
}
