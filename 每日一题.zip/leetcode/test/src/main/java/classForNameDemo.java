import java.lang.reflect.Method;

public interface classForNameDemo {
    public String myString(String name,int age);

}



class demo {
    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException {
        Class<?> classForNameDemo1 = Class.forName("classForNameDemo");
        Method myString = classForNameDemo1.getMethod("myString", String.class, int.class);
    }
}