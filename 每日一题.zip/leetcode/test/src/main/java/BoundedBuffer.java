import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedBuffer {
    final ReentrantLock reentrantLock = new ReentrantLock();
    final Condition isFull = reentrantLock.newCondition();
    final Condition isEmpty = reentrantLock.newCondition();
    Object[] items = new Object[100];
    int itemCount = 0,putPtr = 0,getPur = 0;

    private void put(Object data) throws InterruptedException {
        reentrantLock.lock();
        try {
            while (itemCount == items.length){
                isFull.await();
            }
            items[putPtr ++] = data;
            itemCount ++;
            if(putPtr == items.length) putPtr = 0;
            isEmpty.signal();
        } finally {
            reentrantLock.unlock();
        }
    }

    private Object get() throws InterruptedException {
        reentrantLock.lock();
        try {
            while (itemCount == 0) {
                isEmpty.await();
            }
            Object data = items[getPur ++];
            itemCount --;
            if(getPur == items.length) getPur = 0;
            isFull.signal();
            return data;
        }finally {
            reentrantLock.unlock();
        }
    }

    public static void main(String[] args) {
        BoundedBuffer boundedBuffer = new BoundedBuffer();
        new Thread(() -> {
            for(int i = 0; i < 200;i ++) {
                String temp = "data" + i;
                try {
                    boundedBuffer.put(temp);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"t1").start();
        new Thread(() ->{
            for (int i = 0;i < 200; i ++) {
                try {
                    System.out.println(boundedBuffer.get());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        },"t2").start();
    }
}
