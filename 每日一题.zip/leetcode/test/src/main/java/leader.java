public class leader implements Iwork {
    public void meeting() {
        System.out.println("老板开会");
    }

    public void evaluate() {
        System.out.println("laobandafen");
    }
}
